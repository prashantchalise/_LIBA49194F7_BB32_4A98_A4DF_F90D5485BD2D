
    $(document).ready(function(){
      $(window).load(function() {
        $('#loading').hide();
      });
      $('article').readmore({
        speed: 75,
        maxHeight: 100,
        height: 75
      });
      
      $('.burger-menu-icon').click(function(){
        $('.sidebar-menu-wrapper').addClass('open');
        $("body").addClass("lock-scroll");

      });
      $('.open-submenu').click(function(){
        $(this).parent("li").find(".sidebar-sub-menu").addClass('open');
        // $('.sidebar-sub-menu').addClass('open');

      });
      
      $('.back-menu').click(function(){
        $('.sidebar-sub-menu').removeClass('open');
       
      })
      $('.close-menu').click(function(){
        $('.sidebar-menu-wrapper').removeClass('open');
        $("body").removeClass("lock-scroll");
      })
      $('.close-sub-menu').click(function(){
        $("body").removeClass("lock-scroll");
        $('.sidebar-sub-menu').removeClass('open');
        $('.sidebar-menu-wrapper').removeClass('open');
      })
      
  
      $('.slider-image').slick({
        prevArrow:"<button type='button' class='slick-prev pull-left'><i class='fa fa-angle-left' aria-hidden='true'></i></button>",
        nextArrow:"<button type='button' class='slick-next pull-right'><i class='fa fa-angle-right' aria-hidden='true'></i></button>"
      });
      $('.product-slider').slick({
        slidesToShow:4,
        slidesToScroll:1,
        prevArrow:"<button type='button' class='slick-prev pull-left'><i class='fa fa-angle-left' aria-hidden='true'></i></button>",
        nextArrow:"<button type='button' class='slick-next pull-right'><i class='fa fa-angle-right' aria-hidden='true'></i></button>"
      });
     
     
   
      $('.product-slider-wrapper').slick({
        slidesToShow: 4,
        slidesToScroll: 1,
        prevArrow:"<button type='button' class='slick-prev pull-left'><i class='fa fa-angle-left' aria-hidden='true'></i></button>",
        nextArrow:"<button type='button' class='slick-next pull-right'><i class='fa fa-angle-right' aria-hidden='true'></i></button>",
        responsive: [
         
          
          {
            breakpoint: 992,
            settings: {
              slidesToShow: 1,
              slidesToScroll: 1
            }
          },
         
          // You can unslick at a given breakpoint now by adding:
          // settings: "unslick"
          // instead of a settings object
        ]
     
      });
   
    
    
     
   
 
      $('.accordion-table').click(function() {
       $(this).toggleClass('open'); 
       $('.table-inside').toggle();
    });

   
   
        $("#location").click(function (e) {
            $(".location-block").slideDown(300);
            // e.stopPropagation();
        });
        $("#location").on('click', function (e) {
            e.stopPropagation();
        });
        $("body").on('click', function () {
            $('.location-block').slideUp(300);
        });
        

   
    var w = window.innerWidth;
    if (w >= 992) {

        $(window).scroll(function () {
            if ($(this).scrollTop() > 41) {
                $('.navigation').addClass("shrinking-nav");
            } else {
                $('.navigation').removeClass("shrinking-nav");
            }
        });
    } else {
        $('.navigation').removeClass("shrinking-nav");
    }

    if (w >= 992) {

        $(window).scroll(function () {
            if ($(this).scrollTop() > 180) {
                $('.hanging-search').addClass("shrinking-nav");
            } else {
                $('.hanging-search').removeClass("shrinking-nav");
            }
        });
    } else {
        $('.hanging-search').removeClass("shrinking-nav");
    }
    });
 